function main() {
    let password = "Super secret password";
    let email = "omar@example.com";
    console.log(password);
    console.log(email);
    let token = "asfsfs3r356232hm1337"
}
