function main() {
    let Pass = "Super secret";
    console.log(PAssword);
}
