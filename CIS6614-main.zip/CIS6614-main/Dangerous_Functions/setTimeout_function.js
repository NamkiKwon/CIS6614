setTimeout("anotherfunction();", 1337);
window.setTimeout("console.log('hey')", 500)